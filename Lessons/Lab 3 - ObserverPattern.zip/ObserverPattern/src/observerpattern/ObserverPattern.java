/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package observerpattern;

/**
 *
 * @author Songoku
 */
public class ObserverPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        IObservable s = new server();
        IObserver c = new client(s);
        IObserver c2 = new client(s);
        ((client)c).getjLabel2().setText("Maradona");
        ((client)c2).getjLabel2().setText("Pele");
        s.add(c);
        s.add(c2);
        ((server)s).setVisible(true);
        ((client)c).setVisible(true);
        ((client)c2).setVisible(true);
    }
    
}
