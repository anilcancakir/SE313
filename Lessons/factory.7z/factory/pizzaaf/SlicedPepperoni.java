package headfirst.designpatterns.factory.pizzaaf;

public class SlicedPepperoni implements Pepperoni {

	public String toString() {
		return "Sliced Pepperoni";
	}
}
