/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpattern;

/**
 *
 * @author Songoku
 */
public class VolumeDownCommand implements ICommand{
    private ElectronicDevice device;

    public VolumeDownCommand(ElectronicDevice newDevice) {
        this.device = newDevice;
    }

    @Override
    public void execute() {
        this.device.volumeDown();
    }

    @Override
    public void undo() {
        this.device.volumeUp();
    }
}
