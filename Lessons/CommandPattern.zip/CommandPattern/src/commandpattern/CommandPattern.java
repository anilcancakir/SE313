/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpattern;

import java.util.ArrayList;

/**
 *
 * @author Songoku
 */
public class CommandPattern {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Tv tv = new Tv();
        Radio radio = new Radio();
        Robot r = new Robot();
        TurnOnCommand tOnTv = new TurnOnCommand(tv);
        TurnOffCommand tOff = new TurnOffCommand(tv);
        VolumeUpCommand tUp = new VolumeUpCommand(tv);
        VolumeDownCommand tDown = new VolumeDownCommand(tv);

        RemoteControl controller1 = new RemoteControl(tOnTv, tOff, tUp, tDown);
        RemoteControl controller2 = new RemoteControl(new TurnOnCommand(radio),
                new TurnOffCommand(radio),
                new VolumeUpCommand(radio),
                new VolumeDownCommand(radio));

        controller1.open();
        controller1.increaseVolume();
        controller1.increaseVolume();
        controller1.increaseVolume();
        controller1.undo();
        controller1.shutDown();
        //--------------------------------------
        controller2.open();
        controller2.decreaseVolume();
        controller2.increaseVolume();
        controller2.shutDown();
        //----------------------------------------
        ArrayList<ICommand> turnOnCommands = new ArrayList<>();
        ArrayList<ICommand> turnOffCommands = new ArrayList<>();
        ArrayList<ICommand> volumeUpCommands = new ArrayList<>();
        ArrayList<ICommand> volumeDownCommands = new ArrayList<>();
        ArrayList<ICommand> walkForwardCommands = new ArrayList<>();
        ArrayList<ICommand> walkBackwardCommands = new ArrayList<>();
        turnOnCommands.add(tOnTv);
        turnOnCommands.add(new TurnOnCommand(r));
        turnOnCommands.add(new TurnOnCommand(radio));

        turnOffCommands.add(tOff);
        turnOffCommands.add(new TurnOffCommand(r));
        turnOffCommands.add(new TurnOffCommand(radio));

        volumeUpCommands.add(tUp);
        volumeUpCommands.add(new VolumeUpCommand(r));
        volumeUpCommands.add(new VolumeUpCommand(radio));

        volumeDownCommands.add(tDown);
        volumeDownCommands.add(new VolumeDownCommand(r));
        volumeDownCommands.add(new VolumeDownCommand(radio));

        walkForwardCommands.add(new WalkOneStepForwardCommand(r));
        walkBackwardCommands.add(new WalkOneStepBackwardCommand(r));

        UniversalRemoteController uniControl = new UniversalRemoteController(
                turnOnCommands, turnOffCommands, volumeUpCommands,
                volumeDownCommands, walkForwardCommands, walkBackwardCommands);

        uniControl.open();
        uniControl.volumeUp();
        uniControl.volumeUp();
        uniControl.volumeUp();
        uniControl.volumeUp();
        uniControl.walkForward();
        uniControl.walkForward();
        uniControl.walkForward();
        uniControl.volumeUp();
        uniControl.volumeUp();
        uniControl.undoAll();
        uniControl.walkBackward();
        uniControl.shutDown();
    }

}
