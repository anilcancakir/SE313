/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpattern;

import java.util.ArrayList;
import jdk.nashorn.internal.objects.NativeArray;

/**
 *
 * @author Songoku
 */
public class UniversalRemoteController {

    private ArrayList<ICommand> turnOnCommands;
    private ArrayList<ICommand> turnOffCommands;
    private ArrayList<ICommand> volumeUpCommands;
    private ArrayList<ICommand> volumeDownCommands;
    private ArrayList<ICommand> walkForwardCommands;
    private ArrayList<ICommand> walkBackwardCommands;
    private ArrayList<ICommand> undoLastCommands = null;

    public UniversalRemoteController(ArrayList<ICommand> turnOnCommands,
            ArrayList<ICommand> turnoffCommands,
            ArrayList<ICommand> volumeUpCommands,
            ArrayList<ICommand> volumeDownCommands,
            ArrayList<ICommand> walkFoward, 
            ArrayList<ICommand> walkBackward) {
        this.turnOnCommands = turnOnCommands;
        this.turnOffCommands = turnoffCommands;
        this.volumeUpCommands = volumeUpCommands;
        this.volumeDownCommands = volumeDownCommands;
        this.walkForwardCommands = walkFoward;
        this.walkBackwardCommands = walkBackward;
    }

    public void open() {
        for (ICommand commands : turnOnCommands) {
            commands.execute();
        }
        this.undoLastCommands = turnOnCommands;
    }

    public void shutDown() {
        for (ICommand commands : turnOffCommands) {
            commands.execute();
        }
        this.undoLastCommands =  turnOffCommands;
    }

    public void volumeUp() {
        for (ICommand commands : volumeUpCommands) {
            commands.execute();
        }
        this.undoLastCommands = volumeUpCommands;
    }

    public void volumeDown() {
        for (ICommand commands : volumeDownCommands) {
            commands.execute();
        }
        this.undoLastCommands = volumeDownCommands;
    }

    public void walkForward() {
        for (ICommand commands : walkForwardCommands) {
            commands.execute();
        }
        this.undoLastCommands = walkForwardCommands;
    }

    public void walkBackward() {
        for (ICommand commands : walkBackwardCommands) {
            commands.execute();
        }
        this.undoLastCommands = walkBackwardCommands;
    }

    public void undoAll() {
        if (undoLastCommands != null) {
            for (ICommand commands : undoLastCommands) {
                commands.undo();
            }
        }
    }

}
