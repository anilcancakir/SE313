/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpattern;

/**
 *
 * @author Songoku
 */
public class VolumeUpCommand implements ICommand{
    private ElectronicDevice device;

    public VolumeUpCommand(ElectronicDevice newDevice) {
        this.device = newDevice;
    }

    @Override
    public void execute() {
        this.device.volumeUp();
    }

    @Override
    public void undo() {
        this.device.volumeDown();
    }
    
    
    
}
