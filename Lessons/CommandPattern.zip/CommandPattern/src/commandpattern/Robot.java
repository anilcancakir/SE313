/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpattern;

/**
 *
 * @author Songoku
 */
public class Robot implements ElectronicDevice{
    private int volume = 0;
    private boolean isOpen = false;
    private int xPosition = 0;
    @Override
    public void turnOn() {
        if (isOpen) {
            System.out.println("Robot is allready on");
        } else {
            isOpen = true;
            System.out.println("Robot is on now");
        }
    }

    @Override
    public void turnOff() {
        if (!isOpen) {
            System.out.println("Robot is allready off");
        } else {
            isOpen = true;
            System.out.println("robot is OFF now");
        }
    }

    @Override
    public void volumeUp() {
        if (volume < 5) {
            volume++;
        }
        System.out.println("Robot Volume : " + volume);
    }

    @Override
    public void volumeDown() {
        if (volume > 5) {
            volume--;
        }
        System.out.println("Robot Volume : " + volume);
    }
    
    public void walk(){
        System.out.println("Robot walks from "+xPosition+" to " + ++xPosition);
    }
    
    public void walkBack(){
        System.out.println("Robot walks from "+xPosition+" to " + --xPosition);
    }
}
