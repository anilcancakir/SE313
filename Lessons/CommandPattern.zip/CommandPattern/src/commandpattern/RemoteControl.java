/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpattern;

/**
 *
 * @author Songoku
 */
public class RemoteControl {
    private ICommand turnOn;
    private ICommand turnOff;
    private ICommand volumeUp;
    private ICommand volumeDown;
    private ICommand lastCommand;
    public RemoteControl(TurnOnCommand tON, TurnOffCommand tOFF, VolumeUpCommand vUP, VolumeDownCommand vDOWN) {
        this.turnOn = tON;
        this.turnOff = tOFF;
        this.volumeUp = vUP;
        this.volumeDown = vDOWN;
    }
    
    public void open(){
        this.turnOn.execute();
        lastCommand = turnOn;
    }
    public void shutDown(){
        this.turnOff.execute();
        lastCommand = turnOff;
    }
    public void increaseVolume(){
        this.volumeUp.execute();
        lastCommand = volumeUp;
    }
    public void decreaseVolume(){
        this.volumeDown.execute();
        lastCommand = volumeDown;
    }
    public void undo(){
        if(lastCommand != null){
            lastCommand.undo();
        }
    }
    
}
