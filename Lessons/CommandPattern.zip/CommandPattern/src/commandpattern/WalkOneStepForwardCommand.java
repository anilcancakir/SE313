/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package commandpattern;

/**
 *
 * @author Songoku
 */
public class WalkOneStepForwardCommand implements ICommand{
    private ElectronicDevice device;
    public WalkOneStepForwardCommand(ElectronicDevice newDevice){
        this.device = newDevice;
    }
    
    @Override
    public void execute() {
        if(this.device instanceof Robot){
            ((Robot)this.device).walk();
        }
    }

    @Override
    public void undo() {
        if(this.device instanceof Robot){
            ((Robot)this.device).walkBack();
        }
    }
    
}
